#pragma once
#include <iostream>
using namespace std;

class Point{
    private:
        int x;
        int y;

    public:
        Point(){x=0; y=0;}
        Point(int x, int y): x(x), y(y){}
        Point operator+(const Point &);
        Point operator+=(const Point &);
        Point operator-(const Point &);
        Point operator-=(const Point &);
        friend ostream & operator <<(ostream &, const Point &);
        friend istream & operator >>(istream &, Point &);
};

Point Point::operator+(const Point &toAdd){
  Point z(x + toAdd.x, y + toAdd.y);
  return z;
}

Point Point::operator+=(const Point &toAdd){
  x += toAdd.x;
  y += toAdd.y;
  return *this;
}

Point Point::operator-(const Point &toSubtract){
  Point z(x + toSubtract.x, y + toSubtract.y);
  return z;
}

Point Point::operator-=(const Point &toSubtract){
  x += toSubtract.x;
  y += toSubtract.y;
  return *this;
}

ostream & operator <<(ostream &out, const Point &point){
  out << "[" << point.x << ", " << point.y << "]\n";
  return out;
}

istream & operator >>(istream &in, Point &point){
  cout << "Enter x and y coord" << endl;
  in >> point.x >> point.y;
}