import "bootstrap"

for (let i = 0; i < 5; i++){
    for (let j = 0; j < 4; j++){
        if(document.getElementById('t' + i + j)){
            let spot = document.getElementById('t' + i + j)
            spot.innerHTML = `
            ${i} + ${j} = ${i + j}
            `
        }
    }
}