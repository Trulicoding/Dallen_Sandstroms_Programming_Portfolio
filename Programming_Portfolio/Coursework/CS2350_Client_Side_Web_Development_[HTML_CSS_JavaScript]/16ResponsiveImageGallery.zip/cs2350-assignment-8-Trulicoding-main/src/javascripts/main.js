//TODO - Your ES6 JavaScript code (if any) goes here
import "bootstrap"
let loggedInAs = "Log In"
//alert("Hello! I am an alert box!!")

change()

function getUserName(){
    if(localStorage.getItem('currLogIn') && localStorage.getItem('names') != '[]'){
        return JSON.parse(localStorage.getItem('currLogIn'))
    }
    else{
        return loggedInAs
    }
}

function rename(){
    if (document.querySelector('[type="text"]').value != ""){
    let input = document.querySelector('[type="text"]').value
    localStorage.setItem('currLogIn', JSON.stringify(input))
    change()
    }
    else{
        alert ("Please Enter Username")
    }
}

function change(){
    let userName = getUserName()
    let featured_hotel = document.querySelector(".featured")
    featured_hotel.innerHTML = `
    ${userName}
    `
}

function LogOut(){
    let userName = "Log In"
    let featured_hotel = document.querySelector(".featured")
    featured_hotel.innerHTML = `
    ${userName}
    `
}
/*
function clearText(){
    document.getElementById("myForm").reset();
}
*/
if(document.querySelector(".submit") && document.querySelector(".cancel")){
document.querySelector(".submit").onclick = rename
document.querySelector(".cancel").onclick = LogOut
}