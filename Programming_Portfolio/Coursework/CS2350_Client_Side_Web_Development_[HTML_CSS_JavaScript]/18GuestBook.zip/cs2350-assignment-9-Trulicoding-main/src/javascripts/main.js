//TODO - Your ES6 JavaScript code (if any) goes here
import "bootstrap"

let setOfNames = []

function getNames(){
    if(localStorage.getItem('names') && localStorage.getItem('names') != '[]'){
        return JSON.parse(localStorage.getItem('names'))
    }
    else{
        return setOfNames
    }
}

function addNewName(){
    let names = getNames()
    let FName = document.querySelector("#FirstName").value
    let LName = document.querySelector("#LastName").value
    if (FName && LName){
        for(let i of names){
            if(i.FN == FName && i.LN == LName){
                alert("Already registered")
                return
            }
        }
        names.push({FN: FName, LN: LName})
        localStorage.setItem('names', JSON.stringify(names))
    }

    displayNames()
}

function resetNames(){
    localStorage.setItem("names", [])
    displayNames()
}

function clearText(){
    document.getElementById("myForm").reset();
}

function displayNames(){
    let names = getNames()
    let table_html = ''
    for(let i of names){
        table_html += `
        <tr>
            <td>${i.FN}</td>
            <td>${i.LN}</td>
        </tr>
        `
    }
    document.querySelector("#guests").innerHTML = table_html
}

displayNames()
document.querySelector("#Adda").onclick = addNewName
document.querySelector("#Rst").onclick = clearText
document.querySelector("#Clr").onclick = resetNames
