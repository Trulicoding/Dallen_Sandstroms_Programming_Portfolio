﻿using System.Net.Http;
using System.Numerics;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static DSassignment4.CLStictactoe;

namespace DSassignment4
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        //The buisness logic class
        CLStictactoe TicTacToe;
        //Disables playing the game when it finishes or before it's started
        bool bHasGameStarted;
        //Simple boolean for keeping track of whose turn it is, true = player 1 or O's and false = player 2 or X's
        bool currTurn = true;
        public MainWindow()
        {
            InitializeComponent();
            TicTacToe = new CLStictactoe();
        }
        /// <summary>
        /// Starts the game anew when start button is clicked
        /// </summary>
        private void Bstart_Click(object sender, RoutedEventArgs e)
        {
            //Clear the array in CLStictactoe
            TicTacToe.saBoard = new string[3, 3];
            Lstatus.Content = "Player 1's Turn";
            bHasGameStarted = true;
            resetColors();
            resetLabels();
        }
        /// <summary>
        /// Returns all the grids backgrounds to transparent for a new game
        /// </summary>
        private void resetColors()
        {
            L00.Background = Brushes.Transparent;
            L01.Background = Brushes.Transparent;
            L02.Background = Brushes.Transparent;
            L10.Background = Brushes.Transparent;
            L11.Background = Brushes.Transparent;
            L12.Background = Brushes.Transparent;
            L20.Background = Brushes.Transparent;
            L21.Background = Brushes.Transparent;
            L22.Background = Brushes.Transparent;
        }
        /// <summary>
        /// Clears out the grid for a new game
        /// </summary>
        private void resetLabels()
        {
            L00.Content = "";
            L01.Content = "";
            L02.Content = "";
            L10.Content = "";
            L11.Content = "";
            L12.Content = "";
            L20.Content = "";
            L21.Content = "";
            L22.Content = "";
        }
        /// <summary>
        /// Updates the contents in the statistics group box
        /// </summary>
        private void updateDisplay()
        {
            Lp1wins.Content = "   Player 1 Wins:      " + TicTacToe.iPlayer1Wins;
            Lp2wins.Content = "   Player 2 Wins:      " + TicTacToe.iPlayer2Wins;
            Lties.Content = "   Ties:                     " + TicTacToe.iTies;
        }
        /// <summary>
        /// Whenever a player clicks a label on the grid it will fill in the correct symbol for whose turn it is and check for wins and ties
        /// </summary>
        private void PlayerMoveClick(object sender, RoutedEventArgs e)
        {
            // Cast the sender to a Label

            if (bHasGameStarted)
            {
                if (sender is Label clickedLabel)
                {
                    //set
                    if (currTurn)
                    {
                        clickedLabel.Content = "O";
                        //loadBoard
                        loadBoard(clickedLabel.Name, "O");
                    }
                    else
                    {
                        clickedLabel.Content = "X";
                        //loadBoard
                        loadBoard(clickedLabel.Name, "X");
                    }

                    //Is winning move
                    if (TicTacToe.IsWinningMove())
                    {
                        //highlight winning move
                        highlightWinningMove();
                        //Update Stats
                        if (currTurn)
                        {
                            TicTacToe.iPlayer1Wins++;
                            Lstatus.Content = "Player 1 Wins!";
                            //update display
                            updateDisplay();
                        }
                        else
                        {
                            TicTacToe.iPlayer2Wins++;
                            Lstatus.Content = "Player 2 Wins!";
                            //update display
                            updateDisplay();
                        }
                        bHasGameStarted = false;
                    }
                    //Is tie
                    else if (TicTacToe.IsTie())
                    {
                        //Update Stats
                        TicTacToe.iTies++;
                        Lstatus.Content = "Its a tie!";
                        //update display
                        updateDisplay();
                        bHasGameStarted = false;
                    }
                    else
                    {
                        //Iterate turn
                        currTurn = !currTurn;
                        if (currTurn) {
                            Lstatus.Content = "Player 1's Turn";
                        }
                        else
                        {
                            Lstatus.Content = "Player 2's Turn";
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Updates the CLStictactoe array whenever a player takes a turn
        /// </summary>
        /// <param name="Name">The name of the Label selected</param>
        /// <param name="Content">Either X or O depending on whose turn it is</param>
        private void loadBoard(string Name, string Content)
        {
            //Collects the row from the grid labels name
            int row = int.Parse(Name[1].ToString());
            //Collects the column from the grid labels name
            int column = int.Parse(Name[2].ToString());

            TicTacToe.saBoard[row,column] = Content;
        }

        /// <summary>
        /// Uses an switch method and the enumeration in CLStictactoe to highlight any winning line
        /// </summary>
        private void highlightWinningMove()
        {
            switch (TicTacToe.eWinningMove)
            {
                case WinningMove.Row1:
                    L00.Background = Brushes.Green;
                    L01.Background = Brushes.Green;
                    L02.Background = Brushes.Green;
                    break;
                case WinningMove.Row2:
                    L10.Background = Brushes.Green;
                    L11.Background = Brushes.Green;
                    L12.Background = Brushes.Green;
                    break;
                case WinningMove.Row3:
                    L20.Background = Brushes.Green;
                    L21.Background = Brushes.Green;
                    L22.Background = Brushes.Green;
                    break;
                case WinningMove.Column1:
                    L00.Background = Brushes.Green;
                    L10.Background = Brushes.Green;
                    L20.Background = Brushes.Green;
                    break;
                case WinningMove.Column2:
                    L01.Background = Brushes.Green;
                    L11.Background = Brushes.Green;
                    L21.Background = Brushes.Green;
                    break;
                case WinningMove.Column3:
                    L02.Background = Brushes.Green;
                    L12.Background = Brushes.Green;
                    L22.Background = Brushes.Green;
                    break;
                case WinningMove.DiagAsc:
                    L20.Background = Brushes.Green;
                    L11.Background = Brushes.Green;
                    L02.Background = Brushes.Green;
                    break;
                case WinningMove.DiagDesc:
                    L00.Background = Brushes.Green;
                    L11.Background = Brushes.Green;
                    L22.Background = Brushes.Green;
                    break;
            }
        }
    }
}