﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace DSassignment4
{
    /// <summary>
    /// The buisness logic for tic tac toe
    /// </summary>
    public class CLStictactoe
    {
        //2d array representation of the game board
        public string[,] saBoard;
        //The count for how many times player 1 has won
        public int iPlayer1Wins;
        //The count for how many times player 2 has won
        public int iPlayer2Wins;
        //The count for how many times the game has tied
        public int iTies;
        //Enumeration for storing what winning move has occurred
        public WinningMove eWinningMove;

        /// <summary>
        /// Contains a name for all possible winning moves
        /// </summary>
        public enum WinningMove
        {
            None, Row1, Row2, Row3, Column1, Column2, Column3, DiagDesc, DiagAsc
        }

        /// <summary>
        /// Constructor
        /// </summary>
        public CLStictactoe() 
        {
            saBoard = new string[3, 3];
            iPlayer1Wins = 0;
            iPlayer2Wins = 0;
            iTies = 0;
            eWinningMove = WinningMove.None;
        }
        /// <summary>
        /// Finds winning moves in the saBoard array
        /// </summary>
        public bool IsWinningMove()
        {
            if(IsHorisontalWin() || IsVerticalWin() || IsDiagonalWin())
            {
                return true;
            }
            return false;
        }
        /// <summary>
        /// Checks Horisonal lines for matching symbols
        /// </summary>
        private bool IsHorisontalWin()
        {
            if ((saBoard[0, 0] == "X" && saBoard[0, 1] == "X" && saBoard[0, 2] == "X") ||
                (saBoard[0, 0] == "O" && saBoard[0, 1] == "O" && saBoard[0, 2] == "O"))
            {
                eWinningMove = WinningMove.Row1;
                return true;
            }
            else if ((saBoard[0, 0] == "X" && saBoard[0, 1] == "X" && saBoard[0, 2] == "X") ||
                     (saBoard[0, 0] == "O" && saBoard[0, 1] == "O" && saBoard[0, 2] == "O"))
            {
                eWinningMove = WinningMove.Row2;
                return true;
            }
            else if ((saBoard[0, 0] == "X" && saBoard[0, 1] == "X" && saBoard[0, 2] == "X") ||
                     (saBoard[0, 0] == "O" && saBoard[0, 1] == "O" && saBoard[0, 2] == "O"))
            {
                eWinningMove = WinningMove.Row3;
                return true;
            }

            return false;
        }
        /// <summary>
        /// Checks vertical lines for matching symbols
        /// </summary>
        private bool IsVerticalWin()
        {
            if ((saBoard[0, 0] == "X" && saBoard[1, 0] == "X" && saBoard[2, 0] == "X") ||
                (saBoard[0, 0] == "O" && saBoard[1, 0] == "O" && saBoard[2, 0] == "O"))
            {
                eWinningMove = WinningMove.Column1;
                return true;
            }
            else if ((saBoard[0, 1] == "X" && saBoard[1, 1] == "X" && saBoard[2, 1] == "X") ||
                     (saBoard[0, 1] == "O" && saBoard[1, 1] == "O" && saBoard[2, 1] == "O"))
            {
                eWinningMove = WinningMove.Column2;
                return true;
            }
            else if ((saBoard[0, 2] == "X" && saBoard[1, 2] == "X" && saBoard[2, 2] == "X") ||
                     (saBoard[0, 2] == "O" && saBoard[1, 2] == "O" && saBoard[2, 2] == "O"))
            {
                eWinningMove = WinningMove.Column3;
                return true;
            }

            return false;
        }
        /// <summary>
        /// Checks diagonal lines for matching symbols
        /// </summary>
        private bool IsDiagonalWin()
        {
            if ((saBoard[2, 0] == "X" && saBoard[1, 1] == "X" && saBoard[0, 2] == "X") ||
                (saBoard[2, 0] == "O" && saBoard[1, 1] == "O" && saBoard[0, 2] == "O"))
            {
                eWinningMove = WinningMove.DiagAsc;
                return true;
            }
            else if ((saBoard[0, 0] == "X" && saBoard[1, 1] == "X" && saBoard[2, 2] == "X") ||
                     (saBoard[0, 0] == "O" && saBoard[1, 1] == "O" && saBoard[2, 2] == "O"))
            {
                eWinningMove = WinningMove.DiagDesc;
                return true;
            }

            return false;
        }
        /// <summary>
        /// Checks for if no more moves are avalable
        /// </summary>
        public bool IsTie()
        {
            // Check if all positions are filled
            for (int row = 0; row < 3; row++)
            {
                for (int column = 0; column < 3; column++)
                {
                    if (saBoard[row, column] == null)
                    {
                        // If any spot is empty, it's not a tie
                        return false;
                    }
                }
            }

            return true;
        }

    }
}
