﻿using System;
using System.Runtime.CompilerServices;

class Math1{
    /// <summary>
    /// Main method begin execution of C# math demonstration
    /// </summary>
    static void Main(){
        //Get first number
        Console.Write("Enter first integer: ");
        int number1 = int.Parse(Console.ReadLine());

        //Get second number
        Console.Write("Enter second integer: ");
        int number2 = int.Parse(Console.ReadLine());

        //Sum of entered numbers
        Console.WriteLine($"\n\n{number1} + {number2} = {(number1+number2)}\n");

        //Difference of entered numbers
        Console.WriteLine($"{number1} - {number2} = {(number1 - number2)}\n");

        //Product of entered numbers
        Console.WriteLine($"{number1} * {number2} = {(number1 * number2)}\n");

        //Quotent of entered numbers
        Console.WriteLine($"{number1} / {number2} = {(number1 / number2)}\n");

        //Remainder of entered numbers
        Console.WriteLine($"{number1} % {number2} = {(number1 % number2)}\n\n");

        //Checks if num1 is less than num2
        if (number1 < number2){
            Console.WriteLine($"{number1} is less than {number2}\n");
        }
        else{
            Console.WriteLine($"{number1} is not less than {number2}\n");
        }

        //Checks if num1 is greater than num2
        if (number1 > number2)
        {
            Console.WriteLine($"{number1} is greater than {number2}\n");
        }
        else
        {
            Console.WriteLine($"{number1} is not greater than {number2}\n");
        }

        //Checks if num1 is equal to num2
        if (number1 == number2)
        {
            Console.WriteLine($"{number1} is equal to {number2}\n");
        }
        else
        {
            Console.WriteLine($"{number1} is not equal to {number2}\n");
        }
    }
}