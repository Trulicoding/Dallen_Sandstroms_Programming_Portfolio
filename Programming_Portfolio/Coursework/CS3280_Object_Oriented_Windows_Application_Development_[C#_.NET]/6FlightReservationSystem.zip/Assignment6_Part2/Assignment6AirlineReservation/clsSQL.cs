﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Assignment6AirlineReservation
{
    internal class clsSQL
    {
        /// <summary>
        /// Gets information from the flights table in the data base
        /// </summary>
        public static string GetFlights()
        {
            try
            {
                string sSQL = "SELECT Flight_ID, Flight_Number, Aircraft_Type FROM FLIGHT";
                return sSQL;
            }
            catch (Exception ex)
            {
                throw new Exception(MethodInfo.GetCurrentMethod().DeclaringType.Name + "." +
                    MethodInfo.GetCurrentMethod().Name + " -> " + ex.Message);
            }
        }
        /// <summary>
        /// Gets information from the passengers table in the data base
        /// </summary>
        public static string GetPassengers(string sFlightID)
        {
            try
            {
                string sSQL = "SELECT Passenger.Passenger_ID, First_Name, Last_Name, FPL.Seat_Number " +
                    "FROM Passenger, Flight_Passenger_Link FPL " +
                    "WHERE Passenger.Passenger_ID = FPL.Passenger_ID AND " +
                    "Flight_ID = " + sFlightID;
                return sSQL;
            }
            catch (Exception ex)
            {
                throw new Exception(MethodInfo.GetCurrentMethod().DeclaringType.Name + "." +
                    MethodInfo.GetCurrentMethod().Name + " -> " + ex.Message);
            }
        }

        /// <summary>
        /// Update the seat numbers
        /// </summary>
        public static string UpdateSeatNumber(string sFlightID, string sPassengerID, string sSeatNumber)
        {
            try
            {
                string sSQL = "UPDATE FLIGHT_PASSENGER_LINK " +
                           $"SET Seat_Number = '{sSeatNumber}' " +
                           $"WHERE FLIGHT_ID = {sFlightID} AND PASSENGER_ID = {sPassengerID}";
                return sSQL;
            }
            catch (Exception ex)
            {
                throw new Exception(MethodInfo.GetCurrentMethod().DeclaringType.Name + "." +
                    MethodInfo.GetCurrentMethod().Name + " -> " + ex.Message);
            }
        }

        /// <summary>
        /// Inserting a passenger
        /// </summary>
        public static string InsertPassenger(string sFirstname, string sLastname)
        {
            try
            {
                string sSQL = $"INSERT INTO PASSENGER(First_Name, Last_Name) VALUES('{sFirstname}','{sLastname}')";
                return sSQL;
            }
            catch (Exception ex)
            {
                throw new Exception(MethodInfo.GetCurrentMethod().DeclaringType.Name + "." +
                    MethodInfo.GetCurrentMethod().Name + " -> " + ex.Message);
            }
        }

        /// <summary>
        /// Inserting into the link table
        /// </summary>
        public static string InsertToLinkTable(string sFlightID, string sPassengerID, string sSeatNumber)
        {
            try
            {
                string sSQL = "INSERT INTO Flight_Passenger_Link(Flight_ID, Passenger_ID, Seat_Number) " +
                              $"VALUES( {sFlightID} , {sPassengerID} , {sSeatNumber})";
                return sSQL;
            }
            catch (Exception ex)
            {
                throw new Exception(MethodInfo.GetCurrentMethod().DeclaringType.Name + "." +
                    MethodInfo.GetCurrentMethod().Name + " -> " + ex.Message);
            }
        }

        /// <summary>
        /// Deleting the link
        /// </summary>
        public static string RemoveLink(string sFlightID, string sPassengerID)
        {
            try
            {
                string sSQL = "Delete FROM FLIGHT_PASSENGER_LINK " +
                           $"WHERE FLIGHT_ID = {sFlightID} AND " +
                           $"PASSENGER_ID = {sPassengerID}";
                return sSQL;
            }
            catch (Exception ex)
            {
                throw new Exception(MethodInfo.GetCurrentMethod().DeclaringType.Name + "." +
                    MethodInfo.GetCurrentMethod().Name + " -> " + ex.Message);
            }
        }

        /// <summary>
        /// Deleting the passenger
        /// </summary>
        public static string DeletePassenger(string sPassengerID)
        {
            try
            {
                string sSQL = "Delete FROM PASSENGER " +
                    $"WHERE PASSENGER_ID = {sPassengerID}";
                return sSQL;
            }
            catch (Exception ex)
            {
                throw new Exception(MethodInfo.GetCurrentMethod().DeclaringType.Name + "." +
                    MethodInfo.GetCurrentMethod().Name + " -> " + ex.Message);
            }
        }

        /// <summary>
        /// Query Passenger ID
        /// </summary>
        public static string FindPassengerID(string sFirstname, string sLastname)
        {
            try
            {
                string sSQL = $"SELECT Passenger_ID from Passenger where First_Name = '{sFirstname}' AND Last_Name = '{sLastname}'";
                return sSQL;
            }
            catch (Exception ex)
            {
                throw new Exception(MethodInfo.GetCurrentMethod().DeclaringType.Name + "." +
                    MethodInfo.GetCurrentMethod().Name + " -> " + ex.Message);
            }
        }
    }
}
