﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Assignment6AirlineReservation
{
    /// <summary>
    /// Buisness logic for displaying passengers
    /// </summary>
    class clsPassengerManager
    {
        //list of information associated with each passenger
        public List<clsPassenger> lstPassengers;
        //no limit on returned rows
        private int iRet = 0;
        //new database access class
        clsDataAccess db = new clsDataAccess();
        DataSet ds = new DataSet();

        /// <summary>
        /// creates list of data rows from data stored in database
        /// </summary>
        public List<clsPassenger> GetPassenger(string sFlightID)
        {
            try
            {
                lstPassengers = new List<clsPassenger>();

                //executes SQL statement using code in clsDataAccess
                ds = db.ExecuteSQLStatement(clsSQL.GetPassengers(sFlightID), ref iRet);

                //loops, storing data rows into list
                foreach (DataRow dr in ds.Tables[0].Rows)
                {
                    clsPassenger passenger = new clsPassenger();
                    passenger.PassengerID = dr[0].ToString();
                    passenger.Firstname = dr[1].ToString();
                    passenger.Lastname = dr[2].ToString();
                    passenger.Seat = dr[3].ToString();
                    lstPassengers.Add(passenger);
                }

                return lstPassengers;
            }
            catch (Exception ex)
            {
                throw new Exception(MethodInfo.GetCurrentMethod().DeclaringType.Name + "." +
                    MethodInfo.GetCurrentMethod().Name + " -> " + ex.Message);
            }
        }

        public string AddPassenger(string firstname, string lastname, string flightID, string seatNumber)
        {
            try
            {
                // Insert the new passenger
                string insertPassengerSQL = clsSQL.InsertPassenger(firstname, lastname);
                db.ExecuteNonQuery(insertPassengerSQL);

                // Retrieve the auto-generated Passenger_ID
                string sFindPassengerID = clsSQL.FindPassengerID(firstname, lastname);
                DataSet ds = new DataSet();
                ds = db.ExecuteSQLStatement(sFindPassengerID, ref iRet);

                // Assume the first row contains the desired Passenger_ID
                string passengerID = ds.Tables[0].Rows[0]["Passenger_ID"].ToString();

                // Link the passenger to the flight and assign a seat
                string insertLinkSQL = clsSQL.InsertToLinkTable(flightID, passengerID, seatNumber);
                db.ExecuteNonQuery(insertLinkSQL);

                // Return the auto-generated Passenger_ID
                return passengerID;
            }
            catch (Exception ex)
            {
                throw new Exception(MethodInfo.GetCurrentMethod().DeclaringType.Name + "." +
                                    MethodInfo.GetCurrentMethod().Name + " -> " + ex.Message);
            }
        }

        /// <summary>
        /// Deletes passenger by passenger ID
        /// </summary>
        public void deletePassenger(string passengerID, string flightID)
        {
            try
            {
                // Remove related record from Flight_Passenger_Link table first
                db.ExecuteNonQuery(clsSQL.RemoveLink(flightID, passengerID));

                // Now delete the passenger from the Passenger table
                db.ExecuteNonQuery(clsSQL.DeletePassenger(passengerID));
            }
            catch (Exception ex)
            {
                throw new Exception(MethodInfo.GetCurrentMethod().DeclaringType.Name + "." +
                    MethodInfo.GetCurrentMethod().Name + " -> " + ex.Message);
            }
        }

        /// <summary>
        /// Update the seat of a passenger
        /// </summary>
        public void ChangeSeat(string flightID, string passengerID, string newSeatNumber)
        {
            try
            {
                // Execute the SQL command
                db.ExecuteNonQuery(clsSQL.UpdateSeatNumber(flightID, passengerID, newSeatNumber));

            }
            catch (Exception ex)
            {
                throw new Exception(MethodInfo.GetCurrentMethod().DeclaringType.Name + "." +
                                    MethodInfo.GetCurrentMethod().Name + " -> " + ex.Message);
            }
        }

    }
}
