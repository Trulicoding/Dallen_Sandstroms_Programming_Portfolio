﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment6AirlineReservation
{
    /// <summary>
    /// Class for holding data about flights
    /// </summary>
    public class clsFlight
    {
        public string sFlightID { get; set; }

        public string sFlightNumber { get; set; }

        public string sAircraftType { get; set; }

        /// <summary>
        /// Override of ToString method
        /// Used to display flights in a combo box
        /// </summary>
        public override string ToString()
        {
            // Format the flight information to display in a readable format
            return $"Flight: {sFlightNumber}";
        }
    }
}
