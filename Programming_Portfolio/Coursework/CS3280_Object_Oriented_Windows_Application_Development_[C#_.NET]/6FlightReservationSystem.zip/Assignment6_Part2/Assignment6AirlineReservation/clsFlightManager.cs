﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Assignment6AirlineReservation
{
        /// <summary>
    /// Buisness logic for displaying flights
    /// </summary>
    internal class clsFlightManager
    {
        //list of information associated with each flight
        public List<clsFlight> lstFlights;
        //no limit on returned rows
        private int iRet = 0;

        /// <summary>
        /// creates list of data rows from data stored in database
        /// </summary>
        public List<clsFlight> GetFlights()
        {
            try
            {
                clsDataAccess db = new clsDataAccess();
                DataSet ds = new DataSet();
                lstFlights = new List<clsFlight>();

                //executes SQL statement using code in clsDataAccess
                ds = db.ExecuteSQLStatement(clsSQL.GetFlights(), ref iRet);

                //loops, storing data rows into list
                foreach (DataRow dr in ds.Tables[0].Rows)
                {
                    clsFlight flight = new clsFlight();
                    flight.sFlightID = dr[0].ToString();
                    flight.sFlightNumber = dr[1].ToString();
                    flight.sAircraftType = dr[2].ToString();
                    lstFlights.Add(flight);
                }

                return lstFlights;
            }
            catch (Exception ex)
            {
                throw new Exception(MethodInfo.GetCurrentMethod().DeclaringType.Name + "." +
                    MethodInfo.GetCurrentMethod().Name + " -> " + ex.Message);
            }
        }
    }
}
