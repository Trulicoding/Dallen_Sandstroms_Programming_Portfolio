﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xml.Linq;

namespace Assignment6AirlineReservation
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        //Used to create new isntance of add passenger window
        wndAddPassenger wndAddPass;
        //booleans keep track of selection state
        bool bAddPassengerMode = false;
        bool bChangeSeatMode = false;
        //instantiates new flight manager class
        clsFlightManager flights = new clsFlightManager();
        //instantiats new passenger manager class
        clsPassengerManager passengers = new clsPassengerManager();

        string previousPassengerID = null; //Passenger marked for seat assignment

        public MainWindow()
        {
            try
            {
                InitializeComponent();
                Application.Current.ShutdownMode = ShutdownMode.OnMainWindowClose;
                
                cbChooseFlight.ItemsSource = flights.GetFlights();

            }
            catch (Exception ex)
            {
                HandleError(MethodInfo.GetCurrentMethod().DeclaringType.Name,
                    MethodInfo.GetCurrentMethod().Name, ex.Message);
            }
        }

        /// <summary>
        /// Handles the combo box that allows you to select your flight
        /// </summary>
        private void cbChooseFlight_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                //Make sure not null
                if (cbChooseFlight.SelectedItem is clsFlight SelectedFlight)
                {
                    //Enable other buttons
                    cbChoosePassenger.IsEnabled = true;
                    gPassengerCommands.IsEnabled = true;
                    cmdDeletePassenger.IsEnabled = false; //disable delete button until passenger is selected
                    cmdChangeSeat.IsEnabled = false; //disable change seat button until passenger is selected 
                    //Collect Flight ID from selection
                    string FlightID = SelectedFlight.sFlightID;
                    //Should be using a flight object to get the flight ID here
                    if (FlightID == "1")
                    {
                        CanvasA380.Visibility = Visibility.Hidden;
                        Canvas767.Visibility = Visibility.Visible;
                        //Set passenger combo box
                        cbChoosePassenger.ItemsSource = passengers.GetPassenger(FlightID);
                    }
                    else
                    {
                        Canvas767.Visibility = Visibility.Hidden;
                        CanvasA380.Visibility = Visibility.Visible;
                        //Set passenger combo box
                        cbChoosePassenger.ItemsSource = passengers.GetPassenger(FlightID);
                    }

                    //Call function to change background of occupied seats
                    DisplayTakenSeats(FlightID);
                }
            }
            catch (Exception ex)
            {
                HandleError(MethodInfo.GetCurrentMethod().DeclaringType.Name,
                    MethodInfo.GetCurrentMethod().Name, ex.Message);
            }
        }

        /// <summary>
        /// Iterates through passengers to set their seats to the correct color
        /// </summary>
        private void DisplayTakenSeats(string FlightID)
        {
            try
            {
                Label targetSeat; //the label to be changed
                string labelName; //used t construct the name of label being changed
                int i = 1; //used to iterate through every item in canvas

                //clean canvas
                while (true) 
                {
                    labelName = "Seat";
                    if (FlightID != "1")
                    {
                        labelName += "A";
                    }
                    labelName += i.ToString();
                    //change back to blue
                    targetSeat = (Label)this.FindName(labelName);
                    if (targetSeat != null)
                    {
                        targetSeat.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FF0023FD"));
                    }
                    else
                    {
                        break;
                    }
                    i++;
                }

                //creates passenger list to iterate through
                List<clsPassenger> lstCurrPassengers;
                lstCurrPassengers = passengers.GetPassenger(FlightID);

                //Iterate through passenger list setting occuped spaces to red
                foreach (clsPassenger passenger in lstCurrPassengers)
                {
                    //construct name of label to be changed
                    labelName = "Seat";
                    if (FlightID != "1")
                    {
                        labelName += "A";
                    }
                    labelName += passenger.Seat.ToString();
                    //change label to red
                    targetSeat = (Label)this.FindName(labelName);
                    if (targetSeat != null)
                    {
                        targetSeat.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FFFD0000"));
                    }
                }

            }
            catch (Exception ex)
            {
                HandleError(MethodInfo.GetCurrentMethod().DeclaringType.Name,
                    MethodInfo.GetCurrentMethod().Name, ex.Message);
            }
        }

        /// <summary>
        /// Displays passenger when they're selected from the drop down menu
        /// </summary>
        private void cbChoosePassenger_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                //Make sure not null
                if (cbChoosePassenger.SelectedItem is clsPassenger SelectedPassenger)
                {
                    //enable delete and change buttons
                    cmdDeletePassenger.IsEnabled = true;
                    cmdChangeSeat.IsEnabled = true;
                    //display the passenger seat number
                    lblPassengersSeatNumber.Content = SelectedPassenger.Seat;
                    //Make sure not null
                    if (cbChooseFlight.SelectedItem is clsFlight SelectedFlight)
                    {
                        //reset previous highlights
                        string flightID = SelectedFlight.sFlightID;
                        DisplayTakenSeats(flightID);
                        //Highlight selected passengers seat
                        string labelName = "Seat";
                        if (flightID != "1")
                        {
                            labelName += "A";
                        }
                        labelName += SelectedPassenger.Seat.ToString();
                        //change label to green
                        Label targetSeat = (Label)this.FindName(labelName);
                        if (targetSeat != null)
                        {
                            targetSeat.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FF00FD00"));
                        }
                    }

                }
            }
            catch (Exception ex)
            {
                HandleError(MethodInfo.GetCurrentMethod().DeclaringType.Name, MethodInfo.GetCurrentMethod().Name, ex.Message);
            }
        }

        /// <summary>
        /// Clicking the add passenger button opens the add passenger window
        /// </summary>
        private void cmdAddPassenger_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                this.Hide();
                wndAddPass = new wndAddPassenger();
                wndAddPass.ShowDialog();
                this.Show();
                clsPassenger newPassenger = wndAddPass.GetNewPassenger();
                //if wasn't cancelled or invalid
                if (newPassenger != null && cbChooseFlight.SelectedItem is clsFlight SelectedFlight)
                {
                    //Disable all non-label selections
                    cbChooseFlight.IsEnabled = false;
                    cbChoosePassenger.IsEnabled = false;
                    gPassengerCommands.IsEnabled = false;
                    DisplayTakenSeats(SelectedFlight.sFlightID);
                    //Enable seat selection state
                    bAddPassengerMode = true;
                }
            }
            catch (Exception ex)
            {
                HandleError(MethodInfo.GetCurrentMethod().DeclaringType.Name,
                    MethodInfo.GetCurrentMethod().Name, ex.Message);
            }
        }

        /// <summary>
        /// Change the seat of the passenger currently selected in the passenger combo box
        /// </summary>
        private void cmdChangeSeat_Click(object sender, RoutedEventArgs e)
        {
            //Collect flex box info
            if (cbChoosePassenger.SelectedItem is clsPassenger SelectedPassenger && 
                cbChooseFlight.SelectedItem is clsFlight SelectedFlight)
            {
                //Disable all non-label selections
                cbChooseFlight.IsEnabled = false;
                cbChoosePassenger.IsEnabled = false;
                gPassengerCommands.IsEnabled = false;
                DisplayTakenSeats(SelectedFlight.sFlightID);
                //Enable seat selection state
                previousPassengerID = SelectedPassenger.PassengerID;
                bChangeSeatMode = true;
            }
        }

        /// <summary>
        /// Allows for mouse seat selection
        /// </summary>
        private void cmdSeatSelected(object sender, RoutedEventArgs e)
        {
            try
            {
                //ensure sender was a label
                if (sender is Label clickedLabel && cbChooseFlight.SelectedItem is clsFlight SelectedFlight)
                {
                    string FlightID = SelectedFlight.sFlightID;
                    //reset canvas
                    DisplayTakenSeats(FlightID);

                    //Check is clicked seat belongs to passenger
                    List<clsPassenger> lstCurrPassengers;
                    lstCurrPassengers = passengers.GetPassenger(FlightID);
                    Label targetSeat;
                    string labelName;
                    bool passengerFound = false;
                    //Iterate through seats owned by passengers
                    foreach (clsPassenger passenger in lstCurrPassengers)
                    {
                        labelName = "Seat";
                        if (FlightID != "1")
                        {
                            labelName += "A";
                        }
                        labelName += passenger.Seat.ToString();
                        targetSeat = (Label)this.FindName(labelName);

                        //Trigger if selected seat contains a passenger
                        if (targetSeat != null && targetSeat.Name == clickedLabel.Name)
                        {
                            //if not in any special mode
                            if (!bAddPassengerMode && !bChangeSeatMode)
                            {
                                //iterate through passengers combo box to select 
                                foreach (clsPassenger name in cbChoosePassenger.Items)
                                {
                                    //Triggers if we find what passenger exactly is the one in the selected seat
                                    if (name.ToString() == (passenger.Firstname + " " + passenger.Lastname))
                                    {
                                        passengerFound = true;
                                        // Match found, set combo box accordingly
                                        cbChoosePassenger.SelectedItem = name;
                                        //set clicked labels background to green
                                        clickedLabel.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FF00FD00"));
                                        break;
                                    }
                                }
                            }
                            //We're in add passenger mode
                            else if (bAddPassengerMode && !bChangeSeatMode)
                            {
                                passengerFound = true;

                            }
                            //We're in change seat mode
                            else if (!bAddPassengerMode && bChangeSeatMode)
                            {
                                passengerFound = true;

                            }
                        }
                    }
                        //if empty seat is selected
                        if (!passengerFound)
                        {
                            //We're in normal mode
                            if (!bAddPassengerMode && !bChangeSeatMode)
                            {
                                cbChoosePassenger.SelectedItem = null;
                                lblPassengersSeatNumber.Content = "";
                                //set clicked labels background to green
                                clickedLabel.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FF00FD00"));
                            }
                            //We're in add passenger mode
                            else if (bAddPassengerMode && !bChangeSeatMode)
                            {
                                //get passenger
                                clsPassenger newPassenger = wndAddPass.GetNewPassenger();
                                string newPassengerID = passengers.AddPassenger(newPassenger.Firstname, newPassenger.Lastname, SelectedFlight.sFlightID, clickedLabel.Content.ToString());
                                //set clicked labels background to green
                                clickedLabel.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FF00FD00"));
                                //Return to normal state
                                bAddPassengerMode = false;
                                cbChooseFlight.IsEnabled = true;
                                cbChoosePassenger.IsEnabled = true;
                                gPassengerCommands.IsEnabled = true;

                                // Update UI elements
                                cbChoosePassenger.ItemsSource = passengers.GetPassenger(FlightID);
                                lblPassengersSeatNumber.Content = clickedLabel.Content.ToString();
                                DisplayTakenSeats(SelectedFlight.sFlightID);
                            }
                            //We're in change seat mode
                            else if (!bAddPassengerMode && bChangeSeatMode)
                            {
                                if (!string.IsNullOrEmpty(previousPassengerID))
                                {
                                    // Update seat in database
                                    passengers.ChangeSeat(FlightID, previousPassengerID, clickedLabel.Content.ToString());

                                    // Update canvas
                                    clickedLabel.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FF00FD00"));

                                    // Return to normal state
                                    bChangeSeatMode = false;
                                    previousPassengerID = null;
                                    cbChooseFlight.IsEnabled = true;
                                    cbChoosePassenger.IsEnabled = true;
                                    gPassengerCommands.IsEnabled = true;

                                    // Update UI elements
                                    cbChoosePassenger.ItemsSource = passengers.GetPassenger(FlightID);
                                    lblPassengersSeatNumber.Content = clickedLabel.Content.ToString();
                                    DisplayTakenSeats(SelectedFlight.sFlightID);
                                }
                            }
                        }
                }
            }
            catch (Exception ex)
            {
                HandleError(MethodInfo.GetCurrentMethod().DeclaringType.Name,
                    MethodInfo.GetCurrentMethod().Name, ex.Message);
            }
        }

        /// <summary>
        /// Delete combo box selected passenger from current runtime list
        /// </summary>
        private void cmdDeletePassenger_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                //get passenger from combo box and collect SelectedFlight for flight ID
                if (cbChoosePassenger.SelectedItem is clsPassenger passenger && 
                    cbChooseFlight.SelectedItem is clsFlight SelectedFlight)
                {
                    //Delete passenger
                    passengers.deletePassenger(passenger.PassengerID, SelectedFlight.sFlightID);
                    //Update UI
                    DisplayTakenSeats(SelectedFlight.sFlightID);
                    cbChoosePassenger.ItemsSource = passengers.GetPassenger(SelectedFlight.sFlightID);
                    cbChoosePassenger.SelectedItem = null;
                    lblPassengersSeatNumber.Content = "";
                }
            }
            catch (Exception ex)
            {
                HandleError(MethodInfo.GetCurrentMethod().DeclaringType.Name,
                    MethodInfo.GetCurrentMethod().Name, ex.Message);
            }
        }
        
        /// <summary>
        /// Displays an error message box with the errors location if one is encountered
        /// </summary>
        private void HandleError(string sClass, string sMethod, string sMessage)
        {
            try
            {
                MessageBox.Show(sClass + "." + sMethod + " -> " + sMessage);
            }
            catch (System.Exception ex)
            {
                System.IO.File.AppendAllText(@"C:\Error.txt", Environment.NewLine + "HandleError Exception: " + ex.Message);
            }
        }

    }
}
