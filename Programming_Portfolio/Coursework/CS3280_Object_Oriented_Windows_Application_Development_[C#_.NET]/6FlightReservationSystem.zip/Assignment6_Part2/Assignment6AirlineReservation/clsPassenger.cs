﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment6AirlineReservation
{
    /// <summary>
    /// Class for holding data about passengers
    /// </summary>
    public class clsPassenger
    {
        public string PassengerID { get; set; }

        public string Firstname { get; set; }

        public string Lastname { get; set; }

        public string Seat { get; set; }

        /// <summary>
        /// Override of ToString method
        /// Used to display passenger details in a combo box
        /// </summary>
        public override string ToString()
        {
            // Write passengers name to display in a readable format
            return Firstname + " " + Lastname;
        }
    }
}
