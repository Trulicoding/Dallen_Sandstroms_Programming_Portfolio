using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace DSAssignment2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //initialize user input result;
        int result = -1;
        //initialize current value storage
        int storeVal;
        //initializes my solution for table navigation
        Label tableCoords;

        /// <summary>
        /// TBguess collects the players guess for the dice roll
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void TBguess_TextChanged(object sender, EventArgs e)
        {
            //Get validity of TBguess input and the integer result
            bool validInput = Int32.TryParse(TBguess.Text, out result);

            //If input is integer and within 1-6 give confirmation of valid input,
            if (validInput && (result >= 1 || result <= 6))
            {
                Lerror.Text = ($"{TBguess.Text} has been entered.");
            }
            //else if input is empty write nothing
            else if (TBguess.Text == "")
            {
                Lerror.Text = ("");
            }
            //else write an error
            else
            {
                Lerror.Text = ("ERROR: Please Enter an Integer Between 1 and 6.");
            }
        }

        /// <summary>
        /// Clicking the roll button causes the dice image to randomly roll
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Broll_Click(object sender, EventArgs e)
        {
            //get amount currently stored in timesPlayed and iterate it one before returning it
            Int32.TryParse(LtimesPlayedAmnt.Text, out storeVal);
            storeVal++;
            LtimesPlayedAmnt.Text = storeVal.ToString();

            //initialize dice faces integer
            int diceFace = 1;
            //Create a random number object
            Random rndNumber = new Random();

            //Change appearance of dice 29 times to simulate rolling
            for (int i = 1; i < 30; i++)
            {
                //Using the random number object create two random numbers between 1 and 6
                diceFace = rndNumber.Next(1, 7);
                dicePicture.Image = Image.FromFile("die" + diceFace.ToString() + ".gif");
                dicePicture.Refresh();
                Thread.Sleep(20);
            }

            //get amount currently stored in frequency column and iterate it one before returning it
            tableCoords = Controls.Find($"L{diceFace}1Freq", true).FirstOrDefault() as Label;
            if (tableCoords != null)
            {
                Int32.TryParse(tableCoords.Text, out storeVal);
                storeVal++;
                tableCoords.Text = storeVal.ToString();
            }

            //get amount currently stored in number of times guessed column and iterate it one before returning it
            tableCoords = Controls.Find($"L{result}3Guess", true).FirstOrDefault() as Label;
            if (tableCoords != null)
            {
                Int32.TryParse(tableCoords.Text, out storeVal);
                storeVal++;
                tableCoords.Text = storeVal.ToString();
            }

            //for loop iterates through all of percentage column
            for (int i = 1; i <= 6; i++)
            {
                //Initialize storeVal 2 for this curcumstance
                int storeVal2;
                //get amount currently stored in frequency collumn and divide it by amount of times played to get percentage
                tableCoords = Controls.Find($"L{i}1Freq", true).FirstOrDefault() as Label;
                if (tableCoords != null)
                {
                    Int32.TryParse(tableCoords.Text, out storeVal);
                    Int32.TryParse(LtimesPlayedAmnt.Text, out storeVal2);
                    tableCoords = Controls.Find($"L{i}2Percent", true).FirstOrDefault() as Label;
                    if (tableCoords != null)
                    {
                        //Collect average double by double division
                        double average = (double)storeVal / storeVal2;
                        //Display in percentage format with 2 decimal places
                        tableCoords.Text = $"{average:P2}";
                    }
                }
            }

            //Test if the player has guessed correctly
            if (diceFace == result)
            {
                //get amount currently stored in timesWon and iterate it one before returning it
                Int32.TryParse(LtimesWonAmnt.Text, out storeVal);
                storeVal++;
                LtimesWonAmnt.Text = storeVal.ToString();
            }
            else
            {
                //get amount currently stored in timesLost and iterate it one before returning it
                Int32.TryParse(LtimesLostAmnt.Text, out storeVal);
                storeVal++;
                LtimesLostAmnt.Text = storeVal.ToString();
            }


        }

        /// <summary>
        /// Sets all values to their original state
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Breset_Click(object sender, EventArgs e)
        {
            LtimesWonAmnt.Text = "0";
            LtimesLostAmnt.Text = "0";
            LtimesPlayedAmnt.Text = "0";
            TBguess.Text = "";
            //iterate through collumns in table
            for (int i = 1; i <= 6; i++)
            {
                tableCoords = Controls.Find($"L{i}1Freq", true).FirstOrDefault() as Label;
                if (tableCoords != null)
                {
                    tableCoords.Text = "0";
                }
                tableCoords = Controls.Find($"L{i}2Percent", true).FirstOrDefault() as Label;
                if (tableCoords != null)
                {
                    tableCoords.Text = "0.00%";
                }
                tableCoords = Controls.Find($"L{i}3Guess", true).FirstOrDefault() as Label;
                if (tableCoords != null)
                {
                    tableCoords.Text = "0";
                }
            }
        }
    }
}
