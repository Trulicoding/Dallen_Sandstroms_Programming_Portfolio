﻿
namespace DSAssignment2
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            GBgameInfo = new GroupBox();
            LtimesLostAmnt = new Label();
            LtimesWonAmnt = new Label();
            LtimesPlayedAmnt = new Label();
            LtimesLost = new Label();
            LtimesWon = new Label();
            LtimesPlayed = new Label();
            LguessInstruction = new Label();
            TBguess = new TextBox();
            dicePicture = new PictureBox();
            Broll = new Button();
            Breset = new Button();
            Tstats = new TableLayoutPanel();
            L63Guess = new Label();
            L62Percent = new Label();
            L61Freq = new Label();
            L60six = new Label();
            L53Guess = new Label();
            L52Percent = new Label();
            L51Freq = new Label();
            L50five = new Label();
            L43Guess = new Label();
            L42Percent = new Label();
            L41Freq = new Label();
            L40four = new Label();
            L33Guess = new Label();
            L32Percent = new Label();
            L31Freq = new Label();
            L30three = new Label();
            L23Guess = new Label();
            L22Percent = new Label();
            L21Freq = new Label();
            L20two = new Label();
            L31Guess = new Label();
            L12Percent = new Label();
            L11Freq = new Label();
            L10one = new Label();
            L03guessesHead = new Label();
            L02percentHead = new Label();
            L01frequencyHead = new Label();
            L00faceHead = new Label();
            Lerror = new Label();
            GBgameInfo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dicePicture).BeginInit();
            Tstats.SuspendLayout();
            SuspendLayout();
            // 
            // GBgameInfo
            // 
            GBgameInfo.Controls.Add(LtimesLostAmnt);
            GBgameInfo.Controls.Add(LtimesWonAmnt);
            GBgameInfo.Controls.Add(LtimesPlayedAmnt);
            GBgameInfo.Controls.Add(LtimesLost);
            GBgameInfo.Controls.Add(LtimesWon);
            GBgameInfo.Controls.Add(LtimesPlayed);
            GBgameInfo.Font = new Font("Segoe UI", 11.1F, FontStyle.Bold, GraphicsUnit.Point);
            GBgameInfo.Location = new Point(119, 70);
            GBgameInfo.Name = "GBgameInfo";
            GBgameInfo.Size = new Size(570, 348);
            GBgameInfo.TabIndex = 0;
            GBgameInfo.TabStop = false;
            GBgameInfo.Text = "Game Info";
            // 
            // LtimesLostAmnt
            // 
            LtimesLostAmnt.AutoSize = true;
            LtimesLostAmnt.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            LtimesLostAmnt.Location = new Point(390, 253);
            LtimesLostAmnt.Name = "LtimesLostAmnt";
            LtimesLostAmnt.Size = new Size(34, 41);
            LtimesLostAmnt.TabIndex = 5;
            LtimesLostAmnt.Text = "0";
            // 
            // LtimesWonAmnt
            // 
            LtimesWonAmnt.AutoSize = true;
            LtimesWonAmnt.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            LtimesWonAmnt.Location = new Point(390, 167);
            LtimesWonAmnt.Name = "LtimesWonAmnt";
            LtimesWonAmnt.Size = new Size(34, 41);
            LtimesWonAmnt.TabIndex = 4;
            LtimesWonAmnt.Text = "0";
            // 
            // LtimesPlayedAmnt
            // 
            LtimesPlayedAmnt.AutoSize = true;
            LtimesPlayedAmnt.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            LtimesPlayedAmnt.Location = new Point(390, 79);
            LtimesPlayedAmnt.Name = "LtimesPlayedAmnt";
            LtimesPlayedAmnt.Size = new Size(34, 41);
            LtimesPlayedAmnt.TabIndex = 3;
            LtimesPlayedAmnt.Text = "0";
            // 
            // LtimesLost
            // 
            LtimesLost.AutoSize = true;
            LtimesLost.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            LtimesLost.Location = new Point(36, 253);
            LtimesLost.Name = "LtimesLost";
            LtimesLost.Size = new Size(326, 41);
            LtimesLost.TabIndex = 2;
            LtimesLost.Text = "Number of Times Lost: ";
            // 
            // LtimesWon
            // 
            LtimesWon.AutoSize = true;
            LtimesWon.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            LtimesWon.Location = new Point(36, 167);
            LtimesWon.Name = "LtimesWon";
            LtimesWon.Size = new Size(333, 41);
            LtimesWon.TabIndex = 1;
            LtimesWon.Text = "Number of Times Won: ";
            // 
            // LtimesPlayed
            // 
            LtimesPlayed.AutoSize = true;
            LtimesPlayed.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            LtimesPlayed.Location = new Point(35, 79);
            LtimesPlayed.Name = "LtimesPlayed";
            LtimesPlayed.Size = new Size(359, 41);
            LtimesPlayed.TabIndex = 0;
            LtimesPlayed.Text = "Number of Times Played: ";
            // 
            // LguessInstruction
            // 
            LguessInstruction.AutoSize = true;
            LguessInstruction.Location = new Point(119, 496);
            LguessInstruction.Name = "LguessInstruction";
            LguessInstruction.Size = new Size(326, 41);
            LguessInstruction.TabIndex = 1;
            LguessInstruction.Text = "Enter Your Guess (1-6): ";
            // 
            // TBguess
            // 
            TBguess.Location = new Point(456, 490);
            TBguess.MaxLength = 1;
            TBguess.Name = "TBguess";
            TBguess.Size = new Size(102, 47);
            TBguess.TabIndex = 2;
            TBguess.TextChanged += TBguess_TextChanged;
            // 
            // dicePicture
            // 
            dicePicture.BackgroundImageLayout = ImageLayout.None;
            dicePicture.Location = new Point(119, 636);
            dicePicture.Name = "dicePicture";
            dicePicture.Size = new Size(359, 271);
            dicePicture.SizeMode = PictureBoxSizeMode.StretchImage;
            dicePicture.TabIndex = 3;
            dicePicture.TabStop = false;
            // 
            // Broll
            // 
            Broll.Location = new Point(588, 684);
            Broll.Name = "Broll";
            Broll.Size = new Size(150, 50);
            Broll.TabIndex = 4;
            Broll.Text = "Roll";
            Broll.UseVisualStyleBackColor = true;
            Broll.Click += Broll_Click;
            // 
            // Breset
            // 
            Breset.Location = new Point(588, 813);
            Breset.Name = "Breset";
            Breset.Size = new Size(150, 50);
            Breset.TabIndex = 5;
            Breset.Text = "Reset";
            Breset.UseVisualStyleBackColor = true;
            Breset.Click += Breset_Click;
            // 
            // Tstats
            // 
            Tstats.BackColor = SystemColors.ControlLightLight;
            Tstats.ColumnCount = 4;
            Tstats.ColumnStyles.Add(new ColumnStyle());
            Tstats.ColumnStyles.Add(new ColumnStyle());
            Tstats.ColumnStyles.Add(new ColumnStyle());
            Tstats.ColumnStyles.Add(new ColumnStyle());
            Tstats.Controls.Add(L63Guess, 3, 6);
            Tstats.Controls.Add(L62Percent, 2, 6);
            Tstats.Controls.Add(L61Freq, 1, 6);
            Tstats.Controls.Add(L60six, 0, 6);
            Tstats.Controls.Add(L53Guess, 3, 5);
            Tstats.Controls.Add(L52Percent, 2, 5);
            Tstats.Controls.Add(L51Freq, 1, 5);
            Tstats.Controls.Add(L50five, 0, 5);
            Tstats.Controls.Add(L43Guess, 3, 4);
            Tstats.Controls.Add(L42Percent, 2, 4);
            Tstats.Controls.Add(L41Freq, 1, 4);
            Tstats.Controls.Add(L40four, 0, 4);
            Tstats.Controls.Add(L33Guess, 3, 3);
            Tstats.Controls.Add(L32Percent, 2, 3);
            Tstats.Controls.Add(L31Freq, 1, 3);
            Tstats.Controls.Add(L30three, 0, 3);
            Tstats.Controls.Add(L23Guess, 3, 2);
            Tstats.Controls.Add(L22Percent, 2, 2);
            Tstats.Controls.Add(L21Freq, 1, 2);
            Tstats.Controls.Add(L20two, 0, 2);
            Tstats.Controls.Add(L31Guess, 3, 1);
            Tstats.Controls.Add(L12Percent, 2, 1);
            Tstats.Controls.Add(L11Freq, 1, 1);
            Tstats.Controls.Add(L10one, 0, 1);
            Tstats.Controls.Add(L03guessesHead, 3, 0);
            Tstats.Controls.Add(L02percentHead, 2, 0);
            Tstats.Controls.Add(L01frequencyHead, 1, 0);
            Tstats.Controls.Add(L00faceHead, 0, 0);
            Tstats.Location = new Point(1004, 84);
            Tstats.Name = "Tstats";
            Tstats.RowCount = 7;
            Tstats.RowStyles.Add(new RowStyle(SizeType.Percent, 10F));
            Tstats.RowStyles.Add(new RowStyle(SizeType.Percent, 15F));
            Tstats.RowStyles.Add(new RowStyle(SizeType.Percent, 15F));
            Tstats.RowStyles.Add(new RowStyle(SizeType.Percent, 15F));
            Tstats.RowStyles.Add(new RowStyle(SizeType.Percent, 15F));
            Tstats.RowStyles.Add(new RowStyle(SizeType.Percent, 15F));
            Tstats.RowStyles.Add(new RowStyle(SizeType.Percent, 15F));
            Tstats.Size = new Size(894, 895);
            Tstats.TabIndex = 6;
            // 
            // L63Guess
            // 
            L63Guess.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            L63Guess.AutoSize = true;
            L63Guess.Location = new Point(450, 759);
            L63Guess.Name = "L63Guess";
            L63Guess.Size = new Size(441, 136);
            L63Guess.TabIndex = 27;
            L63Guess.Text = "0";
            L63Guess.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // L62Percent
            // 
            L62Percent.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            L62Percent.AutoSize = true;
            L62Percent.Location = new Point(295, 759);
            L62Percent.Name = "L62Percent";
            L62Percent.Size = new Size(149, 136);
            L62Percent.TabIndex = 26;
            L62Percent.Text = "0.00%";
            L62Percent.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // L61Freq
            // 
            L61Freq.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            L61Freq.AutoSize = true;
            L61Freq.Location = new Point(97, 759);
            L61Freq.Name = "L61Freq";
            L61Freq.Size = new Size(192, 136);
            L61Freq.TabIndex = 25;
            L61Freq.Text = "0";
            L61Freq.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // L60six
            // 
            L60six.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            L60six.AutoSize = true;
            L60six.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            L60six.Location = new Point(3, 759);
            L60six.Name = "L60six";
            L60six.Size = new Size(88, 136);
            L60six.TabIndex = 24;
            L60six.Text = "6";
            L60six.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // L53Guess
            // 
            L53Guess.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            L53Guess.AutoSize = true;
            L53Guess.Location = new Point(450, 625);
            L53Guess.Name = "L53Guess";
            L53Guess.Size = new Size(441, 134);
            L53Guess.TabIndex = 23;
            L53Guess.Text = "0";
            L53Guess.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // L52Percent
            // 
            L52Percent.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            L52Percent.AutoSize = true;
            L52Percent.Location = new Point(295, 625);
            L52Percent.Name = "L52Percent";
            L52Percent.Size = new Size(149, 134);
            L52Percent.TabIndex = 22;
            L52Percent.Text = "0.00%";
            L52Percent.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // L51Freq
            // 
            L51Freq.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            L51Freq.AutoSize = true;
            L51Freq.Location = new Point(97, 625);
            L51Freq.Name = "L51Freq";
            L51Freq.Size = new Size(192, 134);
            L51Freq.TabIndex = 21;
            L51Freq.Text = "0";
            L51Freq.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // L50five
            // 
            L50five.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            L50five.AutoSize = true;
            L50five.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            L50five.Location = new Point(3, 625);
            L50five.Name = "L50five";
            L50five.Size = new Size(88, 134);
            L50five.TabIndex = 20;
            L50five.Text = "5";
            L50five.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // L43Guess
            // 
            L43Guess.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            L43Guess.AutoSize = true;
            L43Guess.Location = new Point(450, 491);
            L43Guess.Name = "L43Guess";
            L43Guess.Size = new Size(441, 134);
            L43Guess.TabIndex = 19;
            L43Guess.Text = "0";
            L43Guess.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // L42Percent
            // 
            L42Percent.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            L42Percent.AutoSize = true;
            L42Percent.Location = new Point(295, 491);
            L42Percent.Name = "L42Percent";
            L42Percent.Size = new Size(149, 134);
            L42Percent.TabIndex = 18;
            L42Percent.Text = "0.00%";
            L42Percent.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // L41Freq
            // 
            L41Freq.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            L41Freq.AutoSize = true;
            L41Freq.Location = new Point(97, 491);
            L41Freq.Name = "L41Freq";
            L41Freq.Size = new Size(192, 134);
            L41Freq.TabIndex = 17;
            L41Freq.Text = "0";
            L41Freq.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // L40four
            // 
            L40four.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            L40four.AutoSize = true;
            L40four.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            L40four.Location = new Point(3, 491);
            L40four.Name = "L40four";
            L40four.Size = new Size(88, 134);
            L40four.TabIndex = 16;
            L40four.Text = "4";
            L40four.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // L33Guess
            // 
            L33Guess.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            L33Guess.AutoSize = true;
            L33Guess.Location = new Point(450, 357);
            L33Guess.Name = "L33Guess";
            L33Guess.Size = new Size(441, 134);
            L33Guess.TabIndex = 15;
            L33Guess.Text = "0";
            L33Guess.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // L32Percent
            // 
            L32Percent.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            L32Percent.AutoSize = true;
            L32Percent.Location = new Point(295, 357);
            L32Percent.Name = "L32Percent";
            L32Percent.Size = new Size(149, 134);
            L32Percent.TabIndex = 14;
            L32Percent.Text = "0.00%";
            L32Percent.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // L31Freq
            // 
            L31Freq.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            L31Freq.AutoSize = true;
            L31Freq.Location = new Point(97, 357);
            L31Freq.Name = "L31Freq";
            L31Freq.Size = new Size(192, 134);
            L31Freq.TabIndex = 13;
            L31Freq.Text = "0";
            L31Freq.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // L30three
            // 
            L30three.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            L30three.AutoSize = true;
            L30three.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            L30three.Location = new Point(3, 357);
            L30three.Name = "L30three";
            L30three.Size = new Size(88, 134);
            L30three.TabIndex = 12;
            L30three.Text = "3";
            L30three.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // L23Guess
            // 
            L23Guess.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            L23Guess.AutoSize = true;
            L23Guess.Location = new Point(450, 223);
            L23Guess.Name = "L23Guess";
            L23Guess.Size = new Size(441, 134);
            L23Guess.TabIndex = 11;
            L23Guess.Text = "0";
            L23Guess.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // L22Percent
            // 
            L22Percent.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            L22Percent.AutoSize = true;
            L22Percent.Location = new Point(295, 223);
            L22Percent.Name = "L22Percent";
            L22Percent.Size = new Size(149, 134);
            L22Percent.TabIndex = 10;
            L22Percent.Text = "0.00%";
            L22Percent.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // L21Freq
            // 
            L21Freq.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            L21Freq.AutoSize = true;
            L21Freq.Location = new Point(97, 223);
            L21Freq.Name = "L21Freq";
            L21Freq.Size = new Size(192, 134);
            L21Freq.TabIndex = 9;
            L21Freq.Text = "0";
            L21Freq.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // L20two
            // 
            L20two.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            L20two.AutoSize = true;
            L20two.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            L20two.Location = new Point(3, 223);
            L20two.Name = "L20two";
            L20two.Size = new Size(88, 134);
            L20two.TabIndex = 8;
            L20two.Text = "2";
            L20two.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // L31Guess
            // 
            L31Guess.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            L31Guess.AutoSize = true;
            L31Guess.Location = new Point(450, 89);
            L31Guess.Name = "L31Guess";
            L31Guess.Size = new Size(441, 134);
            L31Guess.TabIndex = 7;
            L31Guess.Text = "0";
            L31Guess.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // L12Percent
            // 
            L12Percent.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            L12Percent.AutoSize = true;
            L12Percent.Location = new Point(295, 89);
            L12Percent.Name = "L12Percent";
            L12Percent.Size = new Size(149, 134);
            L12Percent.TabIndex = 6;
            L12Percent.Text = "0.00%";
            L12Percent.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // L11Freq
            // 
            L11Freq.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            L11Freq.AutoSize = true;
            L11Freq.Location = new Point(97, 89);
            L11Freq.Name = "L11Freq";
            L11Freq.Size = new Size(192, 134);
            L11Freq.TabIndex = 5;
            L11Freq.Text = "0";
            L11Freq.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // L10one
            // 
            L10one.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            L10one.AutoSize = true;
            L10one.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            L10one.Location = new Point(3, 89);
            L10one.Name = "L10one";
            L10one.Size = new Size(88, 134);
            L10one.TabIndex = 4;
            L10one.Text = "1";
            L10one.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // L03guessesHead
            // 
            L03guessesHead.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            L03guessesHead.AutoSize = true;
            L03guessesHead.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            L03guessesHead.Location = new Point(450, 0);
            L03guessesHead.Name = "L03guessesHead";
            L03guessesHead.Size = new Size(441, 89);
            L03guessesHead.TabIndex = 3;
            L03guessesHead.Text = "NUMBER OF TIMES GUESSED";
            L03guessesHead.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // L02percentHead
            // 
            L02percentHead.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            L02percentHead.AutoSize = true;
            L02percentHead.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            L02percentHead.Location = new Point(295, 0);
            L02percentHead.Name = "L02percentHead";
            L02percentHead.Size = new Size(149, 89);
            L02percentHead.TabIndex = 2;
            L02percentHead.Text = "PERCENT";
            L02percentHead.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // L01frequencyHead
            // 
            L01frequencyHead.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            L01frequencyHead.AutoSize = true;
            L01frequencyHead.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            L01frequencyHead.Location = new Point(97, 0);
            L01frequencyHead.Name = "L01frequencyHead";
            L01frequencyHead.Size = new Size(192, 89);
            L01frequencyHead.TabIndex = 1;
            L01frequencyHead.Text = "FREQUENCY";
            L01frequencyHead.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // L00faceHead
            // 
            L00faceHead.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            L00faceHead.AutoSize = true;
            L00faceHead.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            L00faceHead.Location = new Point(3, 0);
            L00faceHead.Name = "L00faceHead";
            L00faceHead.Size = new Size(88, 89);
            L00faceHead.TabIndex = 0;
            L00faceHead.Text = "FACE";
            L00faceHead.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // Lerror
            // 
            Lerror.AutoSize = true;
            Lerror.Location = new Point(119, 537);
            Lerror.Name = "Lerror";
            Lerror.Size = new Size(0, 41);
            Lerror.TabIndex = 7;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(17F, 41F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.Info;
            ClientSize = new Size(2081, 1223);
            Controls.Add(Lerror);
            Controls.Add(Tstats);
            Controls.Add(Breset);
            Controls.Add(Broll);
            Controls.Add(dicePicture);
            Controls.Add(TBguess);
            Controls.Add(LguessInstruction);
            Controls.Add(GBgameInfo);
            Name = "Form1";
            Text = "Die Guess Game";
            GBgameInfo.ResumeLayout(false);
            GBgameInfo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dicePicture).EndInit();
            Tstats.ResumeLayout(false);
            Tstats.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private GroupBox GBgameInfo;
        private Label LtimesLost;
        private Label LtimesWon;
        private Label LtimesPlayed;
        private Label LguessInstruction;
        private TextBox TBguess;
        private PictureBox dicePicture;
        private Button Broll;
        private Button Breset;
        private TableLayoutPanel Tstats;
        private Label L00faceHead;
        private Label L63Guess;
        private Label L62Percent;
        private Label L61Freq;
        private Label L60six;
        private Label L53Guess;
        private Label L52Percent;
        private Label L51Freq;
        private Label L50five;
        private Label L43Guess;
        private Label L42Percent;
        private Label L41Freq;
        private Label L40four;
        private Label L33Guess;
        private Label L32Percent;
        private Label L31Freq;
        private Label L30three;
        private Label L23Guess;
        private Label L22Percent;
        private Label L21Freq;
        private Label L20two;
        private Label L31Guess;
        private Label L12Percent;
        private Label L11Freq;
        private Label L10one;
        private Label L03guessesHead;
        private Label L02percentHead;
        private Label L01frequencyHead;
        private Label Lerror;
        private Label LtimesLostAmnt;
        private Label LtimesWonAmnt;
        private Label LtimesPlayedAmnt;
    }
}
