﻿using System.Diagnostics.Metrics;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace DSHW3
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        /// <summary>
        /// The number of students entered by the user.
        /// </summary>
        int iNumberOfStudents = 0;

        /// <summary>
        /// The number of assignments entered by the user.
        /// </summary>
        int iNumberOfAssignments = 0;

        /// <summary>
        /// The currently selected student index (0-based).
        /// </summary>
        int iSelectedStudentIndex = 0;

        /// <summary>
        /// Array of student names.
        /// </summary>
        string[] saStudentsNames;

        /// <summary>
        /// 2D array of student scores, where rows correspond to students and columns to assignments.
        /// </summary>
        int[,] iaStudentScores;

        public MainWindow()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Handles the Submit button click to capture the number of students and assignments,
        /// initialize the arrays, and enable relevant UI elements for further interactions.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BcountsSubmit_Click(object sender, RoutedEventArgs e)
        {
            // Validate user input - display error labels
            if (int.TryParse(TBcountsNumStudents.Text, out iNumberOfStudents) &&
                int.TryParse(TBcountsNumAssignments.Text, out iNumberOfAssignments) &&
                iNumberOfStudents >= 1 && iNumberOfStudents <= 10 &&
                iNumberOfAssignments >= 1 && iNumberOfAssignments <= 99)
            {
                // Both inputs are valid
                LcountsSubmitWarining.Content = "";

                // Dynamic assignment number range
                LEnterAssignmentNum.Content = "Enter Assignment Number (1-" + iNumberOfAssignments.ToString() + "):";

                // Enable bottom part of the screen
                BnavFirstStudent.IsEnabled = true;
                BnavPrevStudent.IsEnabled = true;
                BnavNextStudent.IsEnabled = true;
                BnavLastStudent.IsEnabled = true;
                TBcurrStudent.IsEnabled = true;
                BsaveNameCurrStudent.IsEnabled = true;
                TBassignmentNum.IsEnabled = true;
                TBassignmentScore.IsEnabled = true;
                BsaveScoreAssignment.IsEnabled = true;
                BdisplayScore.IsEnabled = true;

                // Disable top inputs
                TBcountsNumStudents.IsEnabled = false;
                TBcountsNumAssignments.IsEnabled = false;
                BcountsSubmit.IsEnabled = false;

                // Initialize the global arrays, not local ones
                saStudentsNames = new string[iNumberOfStudents];
                for (int i = 0; i < iNumberOfStudents; i++)
                {
                    saStudentsNames[i] = "Student #" + (i + 1);  // Add "Student #" prefix
                }

                iaStudentScores = new int[iNumberOfStudents, iNumberOfAssignments];
                for (int i = 0; i < iNumberOfStudents; i++)
                {
                    for (int j = 0; j < iNumberOfAssignments; j++)
                    {
                        iaStudentScores[i, j] = 0;  // Initial score set to 0
                    }
                }
            }
            else
            {
                // Invalid input, display an error message
                LcountsSubmitWarining.Content = "Error, invalid entry";
            }
        }

        /// <summary>
        /// Handles the Reset button click to clear the UI, reset variables, and disable the bottom part of the screen.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BresetScores_Click(object sender, RoutedEventArgs e)
        {
            // Reset window
            TBcountsNumStudents.Text = "";
            TBcountsNumAssignments.Text = "";
            LcountsSubmitWarining.Content = "";
            TBcurrStudent.Text = "";
            TBassignmentScore.Text = "";
            LsaveScorWarining.Content = "";
            iNumberOfStudents = 0;
            iNumberOfAssignments = 0;
            iSelectedStudentIndex = 0;
            LEnterAssignmentNum.Content = "Enter Assignment Number:";
            LBstudentTable.Items.Clear();

            // Enable top inputs
            TBcountsNumStudents.IsEnabled = true;
            TBcountsNumAssignments.IsEnabled = true;
            BcountsSubmit.IsEnabled = true;

            // Disable bottom inputs
            BnavFirstStudent.IsEnabled = false;
            BnavPrevStudent.IsEnabled = false;
            BnavNextStudent.IsEnabled = false;
            BnavLastStudent.IsEnabled = false;
            TBcurrStudent.IsEnabled = false;
            BsaveNameCurrStudent.IsEnabled = false;
            TBassignmentNum.IsEnabled = false;
            TBassignmentScore.IsEnabled = false;
            BsaveScoreAssignment.IsEnabled = false;
            BdisplayScore.IsEnabled = false;
        }

        #region studentNavigation

        /// <summary>
        /// Handles the click event to navigate to the first student.
        /// </summary>
        private void BnavFirstStudent_Click(object sender, RoutedEventArgs e)
        {
            // Set to first student
            iSelectedStudentIndex = 0;
            // Display current student number
            LcurrStudent.Content = "Student #" + (iSelectedStudentIndex + 1).ToString() + ":";
        }

        /// <summary>
        /// Handles the click event to navigate to the previous student.
        /// </summary>
        private void BnavPrevStudent_Click(object sender, RoutedEventArgs e)
        {
            // Disallow going below bounds
            if (iSelectedStudentIndex > 0)
            {
                iSelectedStudentIndex--;
            }
            // Display current student number
            LcurrStudent.Content = "Student #" + (iSelectedStudentIndex + 1).ToString() + ":";
        }

        /// <summary>
        /// Handles the click event to navigate to the next student.
        /// </summary>
        private void BnavNextStudent_Click(object sender, RoutedEventArgs e)
        {
            // Disallow going above bounds
            if (iSelectedStudentIndex < iNumberOfStudents - 1)
            {
                iSelectedStudentIndex++;
            }
            // Display current student number
            LcurrStudent.Content = "Student #" + (iSelectedStudentIndex + 1).ToString() + ":";
        }

        /// <summary>
        /// Handles the click event to navigate to the last student.
        /// </summary>
        private void BnavLastStudent_Click(object sender, RoutedEventArgs e)
        {
            // Set to last student
            iSelectedStudentIndex = iNumberOfStudents - 1;
            // Display current student number
            LcurrStudent.Content = "Student #" + (iSelectedStudentIndex + 1).ToString() + ":";
        }

        #endregion

        /// <summary>
        /// Handles the Save Name button click event to validate and save the student's name.
        /// </summary>
        private void BsaveNameCurrStudent_Click(object sender, RoutedEventArgs e)
        {
            // Validate Name
            if (!string.IsNullOrWhiteSpace(TBcurrStudent.Text))
            {
                // Save name based on index
                saStudentsNames[iSelectedStudentIndex] = TBcurrStudent.Text + "\t";
                TBcurrStudent.Text = "";
                LsaveNameCurrStudentWarining.Content = "";
            }
            else
            {
                // If invalid, show an error message in the warning label
                LsaveNameCurrStudentWarining.Content = "Error, invalid entry";
            }
        }

        /// <summary>
        /// Handles the Save Score button click event to validate and save the student's score for the selected assignment.
        /// </summary>
        private void BsaveScoreAssignment_Click(object sender, RoutedEventArgs e)
        {
            int iAssignmentNum;
            int iScoreNum;

            // Validate Data
            if (int.TryParse(TBassignmentNum.Text, out iAssignmentNum) &&
                int.TryParse(TBassignmentScore.Text, out iScoreNum) &&
                iAssignmentNum >= 1 && iAssignmentNum <= iNumberOfAssignments &&  // Validate assignment range starts from 1
                iScoreNum >= 0 && iScoreNum <= 100)
            {
                LsaveScorWarining.Content = "";
                TBassignmentNum.Text = "";
                TBassignmentScore.Text = "";

                // Save the student's score to the array iaStudentScores, use zero-based index for assignments
                iaStudentScores[iSelectedStudentIndex, iAssignmentNum - 1] = iScoreNum;  // Adjust for zero-based index
            }
            else
            {
                LsaveScorWarining.Content = "Error, invalid entry";
            }
        }

        /// <summary>
        /// Calculates the letter grade based on the student's average score.
        /// </summary>
        /// <param name="average">The student's average score.</param>
        /// <returns>The corresponding letter grade.</returns>
        string GetLetterGrade(double average)
        {
            if (average >= 93)
                return "A";
            else if (average >= 90)
                return "A-";
            else if (average >= 87)
                return "B+";
            else if (average >= 83)
                return "B";
            else if (average >= 80)
                return "B-";
            else if (average >= 77)
                return "C+";
            else if (average >= 73)
                return "C";
            else if (average >= 70)
                return "C-";
            else if (average >= 67)
                return "D+";
            else if (average >= 63)
                return "D";
            else if (average >= 60)
                return "D-";
            else
                return "F";
        }

        /// <summary>
        /// Handles the Display Scores button click event to display the student names, assignment scores, averages, and grades in the ListBox.
        /// </summary>
        private void BdisplayScore_Click(object sender, RoutedEventArgs e)
        {
            // Generate header, number of assignments "STUDENT       #1  #2  #3  #4  #5  AVG GRADE"
            LBstudentTable.Items.Clear();

            // Build the header dynamically
            string header = "STUDENT\t";
            for (int i = 1; i <= iNumberOfAssignments; i++)
            {
                header += $"#{i}\t"; // Add assignment numbers dynamically
            }
            header += "AVG\tGRADE";

            LBstudentTable.Items.Add(header);

            // Outer for loop through students
            for (int studentIndex = 0; studentIndex < saStudentsNames.Length; studentIndex++)
            {
                // Add Name
                string row = saStudentsNames[studentIndex] + "\t";

                // Calculate total score and add each assignment score to the row
                int totalScore = 0;

                // Inner for loop through scores
                for (int assignmentIndex = 0; assignmentIndex < iNumberOfAssignments; assignmentIndex++)
                {
                    int score = iaStudentScores[studentIndex, assignmentIndex];
                    row += score + "\t"; // Add score to row
                    totalScore += score; // Sum scores for average calculation
                }

                // Add up and calculate average
                double average = totalScore / (double)iNumberOfAssignments;
                row += average.ToString("F2") + "\t"; // Add average to row (formatted to 2 decimal places)

                // Call grade letter method
                string grade = GetLetterGrade(average);
                row += grade; // Add grade to row

                // Add the row to the ListBox
                LBstudentTable.Items.Add(row);
            }
        }
    }
}
