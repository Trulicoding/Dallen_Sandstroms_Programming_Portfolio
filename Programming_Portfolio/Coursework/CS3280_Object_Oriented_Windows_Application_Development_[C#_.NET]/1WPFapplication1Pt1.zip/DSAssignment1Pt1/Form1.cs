﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace DSAssignment1Pt1
{
    /// <summary>
    /// The primary class for the assignment 1 form.
    /// </summary>
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        /// <summary>
        /// This is what gets called when the user clicks button 1
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button1_Click(object sender, EventArgs e)
        {
            DialogResult myResult;
            myResult = MessageBox.Show("You Typed: " + textBox1.Text, "Text Output One", MessageBoxButtons.OKCancel, MessageBoxIcon.Error);
            label1.Text = "You clicked the " + myResult.ToString() + " button";
        }

        /// <summary>
        /// This is what gets called when the user clicks button 2
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button2_Click(object sender, EventArgs e)
        {
            DialogResult myResult;
            myResult = MessageBox.Show("You Typed: " + textBox2.Text, "Text Output Two", MessageBoxButtons.YesNo, MessageBoxIcon.Asterisk);
            label2.Text = "You clicked the " + myResult.ToString() + " button";
        }

        /// <summary>
        /// This is what gets called when the user clicks button 3
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button3_Click(object sender, EventArgs e)
        {
            DialogResult myResult;
            myResult = MessageBox.Show("You Typed: " + textBox3.Text, "Text Output Three", MessageBoxButtons.AbortRetryIgnore, MessageBoxIcon.Question);
            label3.Text = "You clicked the " + myResult.ToString() + " button";
        }
    }
}
