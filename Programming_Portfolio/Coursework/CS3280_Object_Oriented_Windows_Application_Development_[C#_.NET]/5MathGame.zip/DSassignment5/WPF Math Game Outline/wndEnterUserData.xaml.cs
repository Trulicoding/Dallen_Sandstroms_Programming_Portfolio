﻿using System.Windows;
using System.Windows.Controls;
using static WPF_Math_Game_Outline.wndMathMenu;

namespace WPF_Math_Game_Outline
{

    /// <summary>
    /// Interaction logic for wndEnterUserData.xaml
    /// </summary>
    public partial class wndEnterUserData : Window
    {
        clsUserData userData;
        public wndEnterUserData(clsUserData data)
        {
            InitializeComponent();
            userData = data;
        }

        private void cmdCloseUserDataForm_Click(object sender, RoutedEventArgs e)
        {
            userData.Susername = TextboxEUDname.Text;
            bool BisValid = int.TryParse(TextboxEUDage.Text, out int Iage);
            userData.Iuserage = Iage;
            //If the inputs are valid and the age is between 3 and 10
            if (!string.IsNullOrEmpty(userData.Susername) && BisValid && userData.Iuserage >= 3 && userData.Iuserage <= 10)
            {
                //Hide Error Label
                LabelEUDerror.Visibility = Visibility.Collapsed;
                //Hide user data form
                this.Hide();
            }
            else
            {
                //Shows Error Label
                LabelEUDerror.Visibility = Visibility.Visible;
            }

        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            this.Hide();
            e.Cancel = true;
        }
    }
}
