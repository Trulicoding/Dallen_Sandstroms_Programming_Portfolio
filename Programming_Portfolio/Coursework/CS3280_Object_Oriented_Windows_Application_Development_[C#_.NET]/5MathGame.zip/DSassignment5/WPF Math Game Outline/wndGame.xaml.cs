﻿using System;
using System.Threading;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Threading;
using static WPF_Math_Game_Outline.wndMathMenu;

namespace WPF_Math_Game_Outline
{
    /// <summary>
    /// Interaction logic for wndGame.xaml
    /// </summary>
    public partial class wndGame : Window
    {
        DispatcherTimer gameTimer;
        //Create Random Field
        Random random = new Random();
        /// <summary>
        /// Stores current math question
        /// </summary>
        int IquestionNum = 1;
        /// <summary>
        /// Stores the answer the input needs to match to be correct
        /// </summary>
        int Ianswer = 0;
        /// <summary>
        /// Stores how many times answered correct
        /// </summary>
        int IcorrectAnswers = 0;
        /// <summary>
        /// Variable to hold the high scores form.
        /// </summary>
        private wndHighScores wndCopyHighScores;

        /// <summary>
        /// Property to get and set the high scores.
        /// </summary>
        public wndHighScores CopyHighScores
        {
            get { return wndCopyHighScores; }
            set { wndCopyHighScores = value; }
        }

        clsUserData userData;
        clsSelectedRadio userEquationType;
        clsUserResults userResults;
        /// <summary>
        /// Initializes the game window
        /// </summary>
        /// <param name="data">User Information</param>
        /// <param name="equationType">What radio option was toggled</param>
        public wndGame(clsUserData data, clsSelectedRadio equationType, clsUserResults results)
        {
            InitializeComponent();
            userData = data;
            userEquationType = equationType;
            userResults = results;
            userResults.Iscore = 0;
            userResults.Imin = 0;
            userResults.Isec = 0;
            gameTimer = new DispatcherTimer();
            gameTimer.Interval = TimeSpan.FromSeconds(1);//make timer go off every second
            gameTimer.Tick += new EventHandler(gameTimer_Tick);
            createQuestion(userEquationType.SelectedOption);//initializes w/ first question
            gameTimer.Start();
        }
        void gameTimer_Tick(object sender, EventArgs e)
        {
            LabelGtimer.Content = DateTime.Now.ToString("mm:ss");
        }
        /// <summary>
        /// Creates a valid math question and its answer
        /// </summary>
        private void createQuestion(int Ioperator)
        {
            char CoperatorSymbol = '?';
            int IleftOperand = random.Next(1, 11);
            int IrightOperand = random.Next(1, 11);
            //generate random operands between 1 and 10 inclusive
            do
            {
                switch (Ioperator)
                {
                    case 0: //addition
                        Ianswer = IleftOperand + IrightOperand;
                        CoperatorSymbol = '+';
                        break;
                    case 1: //subtraction
                        Ianswer = IleftOperand - IrightOperand;
                        CoperatorSymbol = '-';
                        break;
                    case 2: //multiplacation
                        Ianswer = IleftOperand * IrightOperand;
                        CoperatorSymbol = '*';
                        break;
                    case 3: //division
                        if (IleftOperand % IrightOperand != 0) //if remainder exists
                        {
                            Ianswer = -1; //will cause reset
                        }
                        else
                        {
                            Ianswer = IleftOperand / IrightOperand;
                            CoperatorSymbol = '/';
                        }
                        break;
                }
            } while (Ianswer < 0); //Brute force repeats random roll until valid operands acheived
            //Writes equation
            LabelGequation.Content = IleftOperand + " " + CoperatorSymbol + " " + IrightOperand;
        }
        /// <summary>
        /// (Disabled) return to menu option for clicking end game button
        /// </summary>
        private void cmdEndGame_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
        }
        /// <summary>
        /// (Disabled) go to scores window option for clicking high scores button
        /// </summary>
        private void cmdHighScores_Click(object sender, RoutedEventArgs e)
        {
            //Hide the game form
            this.Hide();
            //Show the high scores
            wndCopyHighScores.ShowDialog();
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            this.Hide();
            e.Cancel = true;
        }
        /// <summary>
        /// When user presses the enter key to submit answer
        /// </summary>
        private void ButtonGenter_Click(object sender, RoutedEventArgs e)
        {
            int Iinput;
            bool isValid = int.TryParse(TextboxGanswer.Text, out Iinput);
            if (IquestionNum < 10)
            { //counts how many questions have been asked
                IquestionNum++;
                LabelGcounter.Content = "Question: " + IquestionNum + "/10";
                if (isValid && Ianswer == Iinput) //answer is correct
                {
                    //ButtonGenter.Visibility = Visibility.Collapsed;
                    LabelGresult.Visibility = Visibility.Visible;
                    LabelGresult.Content = "GOOD JOB! You Got it Right!";
                    LabelGresult.Foreground = new BrushConverter().ConvertFromString("#FF20CE12") as Brush; //turn message green

                }
                else // answer is incorrect
                {
                    //ButtonGenter.Visibility = Visibility.Collapsed;
                    LabelGresult.Visibility = Visibility.Visible;
                    LabelGresult.Content = "Oops, Wrong Answer";
                    LabelGresult.Foreground = new BrushConverter().ConvertFromString("#FFEA1313") as Brush; //turn message red
                }
                //System.Threading.Thread.Sleep(3000); // Waits for 3 seconds
                ButtonGenter.Visibility = Visibility.Visible;
                //LabelGresult.Visibility = Visibility.Collapsed;
                createQuestion(userEquationType.SelectedOption); //resets question
                TextboxGanswer.Text = ""; //clears answer box
            }
            else
            {
                //bring up score screen
                this.Hide();
                wndCopyHighScores.ShowDialog();
            }
        }
        /// <summary>
        /// Checks for if the enter key is hit
        /// </summary>
        private void TextboxGanswer_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                ButtonGenter_Click(sender, e);
            }
        }
    }
}
