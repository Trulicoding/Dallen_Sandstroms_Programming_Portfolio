﻿using System.Windows;
using static WPF_Math_Game_Outline.wndMathMenu;

namespace WPF_Math_Game_Outline
{
    /// <summary>
    /// Interaction logic for wndHighScores.xaml
    /// </summary>
    public partial class wndHighScores : Window
    {
        clsUserData userData;
        clsUserResults userResults;
        public wndHighScores(clsUserData data, clsUserResults results)
        {
            InitializeComponent();
            userData = data;
            userResults = results;
            writeResults();
        }
        /// <summary>
        /// Writes to the score page using stored data
        /// </summary>
        private void writeResults()
        {
            LabelHSname.Content = "Name: " + userData.Susername;
            LabelHSage.Content = "Age: " + userData.Iuserage;
            LabelHSscore.Content = userResults.Iscore + " / 10";
            LabelHSscore.Content = userResults.Imin + ":" + userResults.Isec;
        }
        private void cmdCloseHighScores_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            this.Hide();
            e.Cancel = true;
        }
    }
}
